// alert("Welcome Back, Wale Olajide");
let body = document.querySelector("body");
body.innerHTML += ("<small>&copy;2023. Coursebay. All rights reserved</small>")

let sitetoggle = document.querySelector(".site-toggle");
let siteNav = document.querySelector(".site-nav");
sitetoggle.onclick = function(){
    siteNav.classList.toggle("nav-open");
}